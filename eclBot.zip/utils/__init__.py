from .console import c, cprint
