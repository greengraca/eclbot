"""LFG subpackage.

Keep cogs thin by moving LFG models/views/helpers here.
"""
